import java.awt.event.*;
import javax.swing.JButton;

public class Handle implements ActionListener{
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if(arg0.getSource() instanceof JButton){
			JButton b = (JButton)arg0.getSource();
			System.out.println(b.getText());
		}	
	}
}
