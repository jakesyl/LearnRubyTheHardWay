import java.awt.*;
import java.util.*;
import javax.swing.*;
public class FrameTest extends JFrame{
	private String [] names = {"North","Center","South","West","East"};
	public FrameTest(){
		super("example code");
		/* event handler (listener), defined in another java class */
		Handle h = new Handle();
		
		Container c = getContentPane();
		for(int i=0;i<names.length;i++){
			JButton b = new JButton(names[i]);
			c.add(b,names[i]);
			b.addActionListener(h);
		}
		pack();
	}
	
	public static void main(String[] args) {
		FrameTest f = new FrameTest();
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
	}
}
